#include<iostream>
using namespace std;
class base
{
    public:
        int x;
        void get_value()
        {
            cout<<"Enter value of x"<<endl;
            cin>>x;
        }
        void show()
        {
            cout<<"Value of x is "<<x<<endl;
        }
};
int main()
{
    int i;
    base *bp=new base[2];
    cout<<"pointer calling function"<<endl;
    for (i=0;i<2;i++)
    {
        bp->get_value();
        bp->show();
    }
}
